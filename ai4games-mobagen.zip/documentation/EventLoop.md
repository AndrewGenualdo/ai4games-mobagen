# Job Scheduler

EventLoop
TaskQueue
MicroTask

# Multi thread

Main thread
Job/work/??? stealing