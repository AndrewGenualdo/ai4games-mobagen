enum class GameOfLifeTileSetEnum {
  None = 0,  // just to force everyone to implement the tileset
  Square = 1,
  Hexagon = 2,
};