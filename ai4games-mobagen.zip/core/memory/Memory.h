#pragma once

#include <memory>
