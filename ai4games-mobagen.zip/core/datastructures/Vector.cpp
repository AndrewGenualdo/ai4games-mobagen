//
// Created by Alexandre Tolstenko Nogueira on 2023.10.25.
//

#include "Vector.h"
