#ifndef MOBAGEN_ENGINE_SCENE_H_
#define MOBAGEN_ENGINE_SCENE_H_

class Scene {};

#endif  // MOBAGEN_ENGINE_SCENE_H_
